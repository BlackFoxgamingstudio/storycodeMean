var express = require('express');
var mongoose = require('mongoose');
var router = express.Router();
mongoose.connect('mongodb://blackfox:xxx');
var Schema = mongoose.Schema;

var TopicDataSchema = new Schema({
  
  certifucation_id: String,
  num_of_topics: String,
  num_of_tasks: String,
  num_of_steps: String,
  name: String
}, {collection: 'topics'});

var certDataSchema = new Schema({
  name: String,
  num_of_topics: String,
  num_of_tasks: String,
  num_of_steps: String,
  description: String
}, {collection: 'certifications'});


var TopicData = mongoose.model('TopicData', TopicDataSchema);
var certData = mongoose.model('certData', certDataSchema);

  router.get('/production/certifucation/:name/topic/:certifucation_id', (req, res, next) => {
   
    certData.findOne({name: req.params.name})
    .then(function(cdoc){
    TopicData.find({certifucation_id: req.params.certifucation_id})
    .then(function(tdoc) {
      
      res.render('index', {cert: cdoc, topic: tdoc})

      });
      });
});


module.exports = router;
